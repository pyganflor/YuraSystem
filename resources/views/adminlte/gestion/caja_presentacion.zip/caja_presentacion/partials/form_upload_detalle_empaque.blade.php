<form id="form_add_detalle_empaque" enctype="multipart/form-data">
    <div class="row">
        <div class="col-md-12">
            <div class="form-group">
                <label for="Archivo">Archivo</label>
                <input type="file"  id="file" name="file" class="form-control" accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel" required>
            </div>
        </div>
    </div>
</form>
